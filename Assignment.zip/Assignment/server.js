// Dependencies
var express = require('express');
var http = require('http');
var path = require('path');
var socketIO = require('socket.io');var app = express();
var server = http.Server(app);
var io = socketIO(server);app.set('port', 5000);
app.use('/static', express.static(__dirname + '/static'));// Routing
app.get('/', function(request, response) {
  response.sendFile(path.join(__dirname, 'index.html'));
});// Starts the server.
server.listen(5000, function() {
  console.log('Starting server on port 5000');
});

// Add the WebSocket handlers
io.on('connection', function(socket) {
});


let move1, move2;
var checkParity = () => {
if (move1 && move2){
  return true;
}else {
  return false;
}
};
var clearvars = () =>{
move1=move2=null;
};
// Add the WebSocket handlers
io.on('connection', function(socket) {
  socket.on("rock", (retval) =>{
    if (!move1){
      move1 = retval;
    }else {
      move2 = retval;
    }
    console.log(retval);
    if(checkParity()){
      if ((move1 === "rock"&& move2==="scissor") || (move1 === "paper"&& move2==="rock") (move1 === "scissor"&& move2==="paper")){
        socket.emit("winnerfound", {moves: move1})
      }
      else if ((move2 === "rock"&& move1==="scissor") || (move2 === "paper"&& move1==="rock") (move2 === "scissor"&& move1==="paper")){
        socket.emit("winnerfound", {moves: move2})
      }
      else {
        socket.emit("draw", move1);
      }
      clearvars();
    }

  });
  
  socket.on("paper", (retval) =>{
    if (!move1){
      move1 = retval;
    }else {
      move2 = retval;
    }
    console.log(retval);
    if(checkParity()){
      if ((move1 === "rock"&& move2==="scissor") || (move1 === "paper"&& move2==="rock") (move1 === "scissor"&& move2==="paper")){
        socket.emit("winnerfound", {moves: move1})
      }
      else if ((move2 === "rock"&& move1==="scissor") || (move2 === "paper"&& move1==="rock") (move2 === "scissor"&& move1==="paper")){
        socket.emit("winnerfound", {moves: move2})
      }
      else {
        socket.emit("draw", move1);
      }
      clearvars();
    }
  
  });

  socket.on("scissor", (retval) =>{
    if (!move1){
      move1 = retval;
    }else {
      move2= retval;
    }
    console.log(retval);
    if(checkParity()){
      if ((move1 === "rock"&& move2==="scissor") || (move1 === "paper"&& move2==="rock") (move1 === "scissor"&& move2==="paper")){
        socket.emit("winnerfound", {moves: move1})
      }
      else if ((move2 === "rock"&& move1==="scissor") || (move2 === "paper"&& move1==="rock") (move2 === "scissor"&& move1==="paper")){
        socket.emit("winnerfound", {moves: move2})
      }
      else {
        socket.emit("draw", move1);
      }
      clearvars();
    }
    
  });
});