var socket = io();
socket.on('message', function(data) {
  console.log(data);
});

var moves = ["rock", "paper", "scissor"];
document.addEventListener('keydown', function(event) {
  switch (event.keyCode) {
    case 65: // rock
      socket.emit("rock", moves[0]);
      break;
    case 83: // paper
      socket.emit("paper", moves[1]);
      break;
    case 68: // scissor
      socket.emit("scissor", moves[2]);
      break;
  }
});

socket.on("winnerfound", (obj) => {
  window.alert(obj.moves);
});

socket.on("draw", (obj) => {
  window.alert(obj.moves);
});

